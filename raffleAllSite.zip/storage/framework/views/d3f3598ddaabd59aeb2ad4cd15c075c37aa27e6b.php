<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show All Numbers Registered</title>
</head>
<body>
    <table border="1">
    <thead>
    <tr><th>Número</th><th>Nombre</th><th>Teléfono</th><th>Fecha</th></tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $dataNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><th><?php echo e($rowNumber->number); ?></th><th><?php echo e($rowNumber->name); ?></th><th><?php echo e($rowNumber->number_phone); ?></th><th><?php echo e($rowNumber->created_at); ?></th>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</body>
</html><?php /**PATH /storage/ssd1/581/15962581/resources/views/showall.blade.php ENDPATH**/ ?>